
const loginContainer = document.querySelector("#login");
const registerContainer = document.querySelector("#register");
const loginButton = document.querySelector("#login-btn");
const registerButton = document.querySelector("#register-btn");
const switchToRegisterLink = loginContainer.querySelector("a");
const switchToLoginLink = registerContainer.querySelector("a");


function showLogin() {
    loginContainer.style.display = "block";
    registerContainer.style.display = "none";
}

function showRegister() {
    loginContainer.style.display = "none";
    registerContainer.style.display = "block";
}

loginButton.addEventListener("click", showLogin);
registerButton.addEventListener("click", showRegister);


switchToRegisterLink.addEventListener("click", (e) => {
    e.preventDefault();
    showRegister();
});

switchToLoginLink.addEventListener("click", (e) => {
    e.preventDefault();
    showLogin();
});


showLogin();





